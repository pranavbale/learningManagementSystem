package com.pranavbale.learningMahagementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearningMahagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearningMahagementSystemApplication.class, args);
	}

}
