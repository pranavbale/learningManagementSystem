package com.pranavbale.learningMahagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearningMahagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
